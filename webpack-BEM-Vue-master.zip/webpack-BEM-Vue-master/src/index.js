import '@/less/styles.less';
import '@/vendor';
import '@/vue/index';
import '@/common.blocks/index';
import '@/assets/svg/svg-sprite';
