import Vue from 'vue';
import VueTest from './components/vue-test.vue';

/* eslint-disable no-new */
new Vue({
  el: '#vue-app',
  components: {
    VueTest,
  },
});
